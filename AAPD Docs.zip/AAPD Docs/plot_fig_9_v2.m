clear all
close all
MP = load('fig_9_M_P_comp.mat');
MN = load('fig_9_M_N_comp.mat');

SP = load('fig_9_S_P_comp.mat');
SN = load('fig_9_S_N_comp.mat');
%load('fig_9_S_N_fin.mat')
%load('fig_9_S_prop.mat')

binEdges = [0.5 1.5 2.5 3.5 4.5 5.5 6.5 7.5 8.5 9.5 10.5];
bins = {'1', '2', '3', '4', '5', '6', '7', '8', '9', '10'};

idxN_strt = 2;
idxP_strt = 1;

%colororder = [0.8500    0.3250    0.0980;0    0.4470    0.7410]
figure(1)
subplot(3,4,[1 2 3])
groupSize3 = discretize([sort(MN.t_box_c)],binEdges,'categorical',bins);
h = boxchart(groupSize3,[MN.t_dets_c_sh])
h(1).BoxFaceColor=[0    0.4470    0.7410];
h(1).BoxFaceColor=[0.8500    0.3250    0.0980];
h(1).MarkerColor=[0.8500    0.3250    0.0980];
%colororder([0    0.4470    0.7410;0.8500    0.3250    0.0980]); 

xticks('')
set(gca().YAxis,'FontSize',12)
ylim([0 1])
subplot(3,4,4)
plot(idxN_strt:10,MN.freqs_f,'LineWidth',2)
hold on
plot(idxN_strt:10,MN.freqs_t,'LineWidth',2)
xticks('')
ylim([0 430])
set(gca().YAxis,'FontSize',12)
xlim([idxN_strt 10])
subplot(3,4,[5 6 7])
groupSize4 = discretize([sort(MN.t_box_m_c)],binEdges,'categorical',bins);
h = boxchart(groupSize4,[MN.t_dets_m_c_sh])
h(1).BoxFaceColor=[0    0.4470    0.7410];
h(1).BoxFaceColor=[0.8500    0.3250    0.0980];
h(1).MarkerColor=[0.8500    0.3250    0.0980];
xticks('')
set(gca().YAxis,'FontSize',12)
ylim([0 1])
ylabel('\delta')

subplot(3,4,8)
plot(idxN_strt:10,MN.freqs_f_m,'LineWidth',2)
hold on
plot(idxN_strt:10,MN.freqs_t_m,'LineWidth',2)
xlim([idxN_strt 10])
ylim([0 430])
xticks('')
set(gca().YAxis,'FontSize',12)
ylabel('Frequency')
subplot(3,4,[9 10 11])
groupSize5 = discretize([sort(MN.t_box_mm_c)],binEdges,'categorical',bins);
h = boxchart(groupSize5,[MN.t_dets_mm_c_sh])
h(1).BoxFaceColor=[0    0.4470    0.7410];
h(1).BoxFaceColor=[0.8500    0.3250    0.0980];
h(1).MarkerColor=[0.8500    0.3250    0.0980];
%xlim([0 10])
xticklabels({'','2','3','4','5','6','7','8','9','10'})
%colororder([0    0.4470    0.7410;0.8500    0.3250    0.0980]); 


set(gca().YAxis,'FontSize',12)
set(gca().XAxis,'FontSize',12)
xlabel('Swarm Size, \it N')


ylim([0 1])
subplot(3,4,12)
plot(idxN_strt:10,MN.freqs_f_mm,'LineWidth',2)
hold on
plot(idxN_strt:10,MN.freqs_t_mm,'LineWidth',2)
xlim([idxN_strt 10])
ylim([0 430])
set(gca().XAxis,'FontSize',12)
set(gca().YAxis,'FontSize',12)

xlabel('Swarm Size, \it N')

figure(2)
subplot(3,4,[1 2 3])
groupSize3 = discretize([sort(MP.t_box_c)],binEdges,'categorical',bins);
h = boxchart(groupSize3,[MP.t_dets_c_sh])
h(1).BoxFaceColor=[0    0.4470    0.7410];
h(1).BoxFaceColor=[0.8500    0.3250    0.0980];
h(1).MarkerColor=[0.8500    0.3250    0.0980];
%colororder([0    0.4470    0.7410;0.8500    0.3250    0.0980]); 

xticks('')
set(gca().YAxis,'FontSize',12)
ylim([0 1])
%xlim([idxP_strt 10])
subplot(3,4,4)
plot(idxP_strt:10,MP.freqs_f,'LineWidth',2)
hold on
plot(idxP_strt:10,MP.freqs_t,'LineWidth',2)
xticks('')
ylim([0 430])
set(gca().YAxis,'FontSize',12)
xlim([idxP_strt 10])
subplot(3,4,[5 6 7])
groupSize4 = discretize([sort(MP.t_box_m_c)],binEdges,'categorical',bins);
h = boxchart(groupSize4,[MP.t_dets_m_c_sh])
h(1).BoxFaceColor=[0    0.4470    0.7410];
h(1).BoxFaceColor=[0.8500    0.3250    0.0980];
h(1).MarkerColor=[0.8500    0.3250    0.0980];
xticks('')
set(gca().YAxis,'FontSize',12)
ylim([0 1])
ylabel('d_s')

subplot(3,4,8)
plot(idxP_strt:10,MP.freqs_f_m,'LineWidth',2)
hold on
plot(idxP_strt:10,MP.freqs_t_m,'LineWidth',2)
xlim([idxP_strt 10])
ylim([0 430])
xticks('')
set(gca().YAxis,'FontSize',12)
ylabel('Frequency')
subplot(3,4,[9 10 11])
groupSize5 = discretize([sort(MP.t_box_mm_c)],binEdges,'categorical',bins);
h = boxchart(groupSize5,[MP.t_dets_mm_c_sh])
h(1).BoxFaceColor=[0    0.4470    0.7410];
h(1).BoxFaceColor=[0.8500    0.3250    0.0980];
h(1).MarkerColor=[0.8500    0.3250    0.0980];
%colororder([0    0.4470    0.7410;0.8500    0.3250    0.0980]); 


set(gca().YAxis,'FontSize',12)
set(gca().XAxis,'FontSize',12)
xlabel('No. of Degrading Robots')


ylim([0 1])
subplot(3,4,12)
plot(idxP_strt:10,MP.freqs_f_mm,'LineWidth',2)
hold on
plot(idxP_strt:10,MP.freqs_t_mm,'LineWidth',2)
xlim([idxP_strt 10])
ylim([0 430])
set(gca().XAxis,'FontSize',12)
set(gca().YAxis,'FontSize',12)

xlabel('No. of Degrading Robots')

figure(3)
subplot(3,4,[1 2 3])
groupSize3 = discretize([sort(SN.t_box_c)],binEdges,'categorical',bins);
h = boxchart(groupSize3,[SN.t_dets_c_sh])
h(1).BoxFaceColor=[0    0.4470    0.7410];
h(1).BoxFaceColor=[0.8500    0.3250    0.0980];
h(1).MarkerColor=[0.8500    0.3250    0.0980];
%colororder([0    0.4470    0.7410;0.8500    0.3250    0.0980]); 

xticks('')
set(gca().YAxis,'FontSize',12)
ylim([0 1])
subplot(3,4,4)
plot(idxN_strt:10,SN.freqs_f,'LineWidth',2)
hold on
plot(idxN_strt:10,SN.freqs_t,'LineWidth',2)
xlim([idxN_strt 10])
xticks('')
ylim([0 430])
set(gca().YAxis,'FontSize',12)
%xlim([idxP_strt 10])
subplot(3,4,[5 6 7])
groupSize4 = discretize([sort(SN.t_box_m_c)],binEdges,'categorical',bins);
h = boxchart(groupSize4,[SN.t_dets_m_c_sh])
h(1).BoxFaceColor=[0    0.4470    0.7410];
h(1).BoxFaceColor=[0.8500    0.3250    0.0980];
h(1).MarkerColor=[0.8500    0.3250    0.0980];
xticks('')
set(gca().YAxis,'FontSize',12)
ylim([0 1])
ylabel('\delta')

subplot(3,4,8)
plot(idxN_strt:10,SN.freqs_f_m,'LineWidth',2)
hold on
plot(idxN_strt:10,SN.freqs_t_m,'LineWidth',2)
xlim([idxN_strt 10])
ylim([0 430])
xticks('')
set(gca().YAxis,'FontSize',12)
ylabel('Frequency')
subplot(3,4,[9 10 11])
groupSize5 = discretize([sort(SN.t_box_mm_c)],binEdges,'categorical',bins);
h = boxchart(groupSize5,[SN.t_dets_mm_c_sh])
h(1).BoxFaceColor=[0    0.4470    0.7410];
h(1).BoxFaceColor=[0.8500    0.3250    0.0980];
h(1).MarkerColor=[0.8500    0.3250    0.0980];
%xlim([0 10])
xticklabels({'','2','3','4','5','6','7','8','9','10'})
%colororder([0    0.4470    0.7410;0.8500    0.3250    0.0980]); 


set(gca().YAxis,'FontSize',12)
set(gca().XAxis,'FontSize',12)
xlabel('Swarm Size, \it N')


ylim([0 1])
subplot(3,4,12)
plot(idxN_strt:10,SN.freqs_f_mm,'LineWidth',2)
hold on
plot(idxN_strt:10,SN.freqs_t_mm,'LineWidth',2)
xlim([idxN_strt 10])
ylim([0 430])
set(gca().XAxis,'FontSize',12)
set(gca().YAxis,'FontSize',12)

xlabel('Swarm Size, \it N')

figure(4)
subplot(3,4,[1 2 3])
groupSize3 = discretize([sort(SP.t_box_c)],binEdges,'categorical',bins);
h = boxchart(groupSize3,[SP.t_dets_c_sh])
h(1).BoxFaceColor=[0    0.4470    0.7410];
h(1).BoxFaceColor=[0.8500    0.3250    0.0980];
h(1).MarkerColor=[0.8500    0.3250    0.0980];
%colororder([0    0.4470    0.7410;0.8500    0.3250    0.0980]); 

xticks('')
set(gca().YAxis,'FontSize',12)
ylim([0 1])
%xlim([idxP_strt 10])
subplot(3,4,4)
plot(idxP_strt:10,SP.freqs_f,'LineWidth',2)
hold on
plot(idxP_strt:10,SP.freqs_t,'LineWidth',2)
xticks('')
ylim([0 430])
set(gca().YAxis,'FontSize',12)
xlim([idxP_strt 10])
subplot(3,4,[5 6 7])
groupSize4 = discretize([sort(SP.t_box_m_c)],binEdges,'categorical',bins);
h = boxchart(groupSize4,[SP.t_dets_m_c_sh])
h(1).BoxFaceColor=[0    0.4470    0.7410];
h(1).BoxFaceColor=[0.8500    0.3250    0.0980];
h(1).MarkerColor=[0.8500    0.3250    0.0980];
xticks('')
set(gca().YAxis,'FontSize',12)
ylim([0 1])
ylabel('d_s')

subplot(3,4,8)
plot(idxP_strt:10,SP.freqs_f_m,'LineWidth',2)
hold on
plot(idxP_strt:10,SP.freqs_t_m,'LineWidth',2)
xlim([idxP_strt 10])
ylim([0 430])
xticks('')
set(gca().YAxis,'FontSize',12)
ylabel('Frequency')
subplot(3,4,[9 10 11])
groupSize5 = discretize([sort(SP.t_box_mm_c)],binEdges,'categorical',bins);
h = boxchart(groupSize5,[SP.t_dets_mm_c_sh])
h(1).BoxFaceColor=[0    0.4470    0.7410];
h(1).BoxFaceColor=[0.8500    0.3250    0.0980];
h(1).MarkerColor=[0.8500    0.3250    0.0980];
%colororder([0    0.4470    0.7410;0.8500    0.3250    0.0980]); 


set(gca().YAxis,'FontSize',12)
set(gca().XAxis,'FontSize',12)
xlabel('No. of Degrading Robots')


ylim([0 1])
subplot(3,4,12)
plot(idxP_strt:10,SP.freqs_f_mm,'LineWidth',2)
hold on
plot(idxP_strt:10,SP.freqs_t_mm,'LineWidth',2)
xlim([idxP_strt 10])
ylim([0 430])
set(gca().XAxis,'FontSize',12)
set(gca().YAxis,'FontSize',12)

xlabel('No. of Degrading Robots')


