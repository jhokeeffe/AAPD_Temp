clear all
close all
M75 = load('10R_data_75M.mat');
M85 = load('10R_data_85M.mat');
M95 = load('10R_data_95M.mat');
S75 = load('10R_data_75S.mat');
S85 = load('10R_data_85S.mat');
S95 = load('10R_data_95S.mat');


binEdges = [25 35 45 55 65 75 85 95];
bins = {'0.3', '0.4', '0.5', '0.6', '0.7', '0.8', '0.9'};

figure(1)
subplot(2,6,1)
groupSize3 = discretize([10*ones(size(M75.tp_props)); 10*ones(size(M75.fp_props_single)); 20*ones(size(M75.tp_props_m)); 20*ones(size(M75.fp_props_m_single));30*ones(size(M75.tp_props_mm)); 30*ones(size(M75.fp_props_mm_single))],[ 5 15 25 35],'categorical',{'Y_0','Y_{M.1}','Y_{M.2}'});
boxchart(groupSize3,[M75.tp_props; M75.fp_props_single; M75.tp_props_m; M75.fp_props_m_single;M75.tp_props_mm; M75.fp_props_mm_single], 'GroupByColor',[ones(size(M75.tp_props)); zeros(size(M75.fp_props_single)); ones(size(M75.tp_props_m)); zeros(size(M75.fp_props_m_single));ones(size(M75.tp_props_mm)); zeros(size(M75.fp_props_mm_single))])
ylim([0 1])
xticks('')
ylabel('\Psi')
set(gca().YAxis,'FontSize',12)
set(gca().XAxis,'FontSize',12)

subplot(2,6,2)
groupSize3 = discretize([10*ones(size(M85.tp_props)); 10*ones(size(M85.fp_props_single)); 20*ones(size(M85.tp_props_m)); 20*ones(size(M85.fp_props_m_single));30*ones(size(M85.tp_props_mm)); 30*ones(size(M85.fp_props_mm_single))],[ 5 15 25 35],'categorical',{'Y_0','Y_{M.1}','Y_{M.2}'});
boxchart(groupSize3,[M85.tp_props; M85.fp_props_single; M85.tp_props_m; M85.fp_props_m_single;M85.tp_props_mm; M85.fp_props_mm_single], 'GroupByColor',[ones(size(M85.tp_props)); zeros(size(M85.fp_props_single)); ones(size(M85.tp_props_m)); zeros(size(M85.fp_props_m_single));ones(size(M85.tp_props_mm)); zeros(size(M85.fp_props_mm_single))])
xticks('')
yticks('')
ylim([0 1])
set(gca().YAxis,'FontSize',12)
set(gca().XAxis,'FontSize',12)

subplot(2,6,3)
groupSize3 = discretize([10*ones(size(M95.tp_props)); 10*ones(size(M95.fp_props_single)); 20*ones(size(M95.tp_props_m)); 20*ones(size(M95.fp_props_m_single));30*ones(size(M95.tp_props_mm)); 30*ones(size(M95.fp_props_mm_single))],[ 5 15 25 35],'categorical',{'Y_0','Y_{M.1}','Y_{M.2}'});
boxchart(groupSize3,[M95.tp_props; M95.fp_props_single; M95.tp_props_m; M95.fp_props_m_single;M95.tp_props_mm; M95.fp_props_mm_single], 'GroupByColor',[ones(size(M95.tp_props)); zeros(size(M95.fp_props_single)); ones(size(M95.tp_props_m)); zeros(size(M95.fp_props_m_single));ones(size(M95.tp_props_mm)); zeros(size(M95.fp_props_mm_single))])
xticks('')
yticks('')
ylim([0 1])
set(gca().YAxis,'FontSize',12)
set(gca().XAxis,'FontSize',12)

subplot(2,6,4)
groupSize3 = discretize([10*ones(size(S75.tp_props)); 10*ones(size(S75.fp_props_single)); 20*ones(size(S75.tp_props_m)); 20*ones(size(S75.fp_props_m_single));30*ones(size(S75.tp_props_mm)); 30*ones(size(S75.fp_props_mm_single))],[ 5 15 25 35],'categorical',{'Y_0','Y_{S.1}','Y_{S.2}'});
boxchart(groupSize3,[S75.tp_props; S75.fp_props_single; S75.tp_props_m; S75.fp_props_m_single;S75.tp_props_mm; S75.fp_props_mm_single], 'GroupByColor',[ones(size(S75.tp_props)); zeros(size(S75.fp_props_single)); ones(size(S75.tp_props_m)); zeros(size(S75.fp_props_m_single));ones(size(S75.tp_props_mm)); zeros(size(S75.fp_props_mm_single))])
xticks('')
yticks('')
ylim([0 1])
set(gca().YAxis,'FontSize',12)
set(gca().XAxis,'FontSize',12)

subplot(2,6,5)
groupSize3 = discretize([10*ones(size(S85.tp_props)); 10*ones(size(S85.fp_props_single)); 20*ones(size(S85.tp_props_m)); 20*ones(size(S85.fp_props_m_single));30*ones(size(S85.tp_props_mm)); 30*ones(size(S85.fp_props_mm_single))],[ 5 15 25 35],'categorical',{'Y_0','Y_{M.1}','Y_{M.2}'});
boxchart(groupSize3,[S85.tp_props; S85.fp_props_single; S85.tp_props_m; S85.fp_props_m_single;S85.tp_props_mm; S85.fp_props_mm_single], 'GroupByColor',[ones(size(S85.tp_props)); zeros(size(S85.fp_props_single)); ones(size(S85.tp_props_m)); zeros(size(S85.fp_props_m_single));ones(size(S85.tp_props_mm)); zeros(size(S85.fp_props_mm_single))])
xticks('')
yticks('')
ylim([0 1])
set(gca().YAxis,'FontSize',12)
set(gca().XAxis,'FontSize',12)

subplot(2,6,6)
groupSize3 = discretize([10*ones(size(S95.tp_props)); 10*ones(size(S95.fp_props_single)); 20*ones(size(S95.tp_props_m)); 20*ones(size(S95.fp_props_m_single));30*ones(size(S95.tp_props_mm)); 30*ones(size(S95.fp_props_mm_single))],[ 5 15 25 35],'categorical',{'Y_0','Y_{M.1}','Y_{M.2}'});
boxchart(groupSize3,[S95.tp_props; S95.fp_props_single; S95.tp_props_m; S95.fp_props_m_single;S95.tp_props_mm; S95.fp_props_mm_single], 'GroupByColor',[ones(size(S95.tp_props)); zeros(size(S95.fp_props_single)); ones(size(S95.tp_props_m)); zeros(size(S95.fp_props_m_single));ones(size(S95.tp_props_mm)); zeros(size(S95.fp_props_mm_single))])
ylim([0 1])
yticks('')
xticks('')
set(gca().YAxis,'FontSize',12)
set(gca().XAxis,'FontSize',12)

subplot(2,6,7)
groupSize3 = discretize([10*ones(size(min(M75.dt,[],2))); 20*ones(size(min(M75.dt_m,[],2))); 30*ones(size(min(M75.dt_mm,[],2))) ],[ 5 15 25 35],'categorical',{'Y_0','Y_{M.1}','Y_{M.2}'});
boxchart(groupSize3,[min(M75.dt,[],2); min(M75.dt_m,[],2); min(M75.dt_mm,[],2)],'GroupByColor',[ones(size(min(M75.dt,[],2))); ones(size(min(M75.dt_m,[],2))); ones(size(min(M75.dt_mm,[],2)))],'BoxFaceColor','red','MarkerColor','red')
set(gca().YAxis,'FontSize',12)
set(gca().XAxis,'FontSize',12)
ylabel('\delta')
ylim([0 1])

subplot(2,6,8)
groupSize3 = discretize([10*ones(size(min(M85.dt,[],2))); 20*ones(size(min(M85.dt_m,[],2))); 30*ones(size(min(M85.dt_mm,[],2))) ],[ 5 15 25 35],'categorical',{'Y_0','Y_{M.1}','Y_{M.2}'});
boxchart(groupSize3,[min(M85.dt,[],2); min(M85.dt_m,[],2); min(M85.dt_mm,[],2)],'GroupByColor',[ones(size(min(M85.dt,[],2))); ones(size(min(M85.dt_m,[],2))); ones(size(min(M85.dt_mm,[],2)))],'BoxFaceColor','red','MarkerColor','red')
yticks('')
ylim([0 1])
set(gca().YAxis,'FontSize',12)
set(gca().XAxis,'FontSize',12)

subplot(2,6,9)
groupSize3 = discretize([10*ones(size(min(M95.dt,[],2))); 20*ones(size(min(M95.dt_m,[],2))); 30*ones(size(min(M95.dt_mm,[],2))) ],[ 5 15 25 35],'categorical',{'Y_0','Y_{M.1}','Y_{M.2}'});
boxchart(groupSize3,[min(M95.dt,[],2); min(M95.dt_m,[],2); min(M95.dt_mm,[],2)],'GroupByColor',[ones(size(min(M95.dt,[],2))); ones(size(min(M95.dt_m,[],2))); ones(size(min(M95.dt_mm,[],2)))],'BoxFaceColor','red','MarkerColor','red')
yticks('')
ylim([0 1])
set(gca().YAxis,'FontSize',12)
set(gca().XAxis,'FontSize',12)

subplot(2,6,10)
groupSize3 = discretize([10*ones(size(min(S75.dt,[],2))); 20*ones(size(min(S75.dt_m,[],2))); 30*ones(size(min(S75.dt_mm,[],2))) ],[ 5 15 25 35],'categorical',{'Y_0','Y_{S.1}','Y_{S.2}'});
boxchart(groupSize3,[min(S75.dt,[],2); min(S75.dt_m,[],2); min(S75.dt_mm,[],2)],'GroupByColor',[ones(size(min(S75.dt,[],2))); ones(size(min(S75.dt_m,[],2))); ones(size(min(S75.dt_mm,[],2)))],'BoxFaceColor','red','MarkerColor','red')
yticks('')
ylim([0 1])
set(gca().YAxis,'FontSize',12)
set(gca().XAxis,'FontSize',12)

subplot(2,6,11)
groupSize3 = discretize([10*ones(size(min(S85.dt,[],2))); 20*ones(size(min(S85.dt_m,[],2))); 30*ones(size(min(S85.dt_mm,[],2))) ],[ 5 15 25 35],'categorical',{'Y_0','Y_{S.1}','Y_{S.2}'});
boxchart(groupSize3,[min(S85.dt,[],2); min(S85.dt_m,[],2); min(S85.dt_mm,[],2)],'GroupByColor',[ones(size(min(S85.dt,[],2))); ones(size(min(S85.dt_m,[],2))); ones(size(min(S85.dt_mm,[],2)))],'BoxFaceColor','red','MarkerColor','red')
yticks('')
ylim([0 1])
set(gca().YAxis,'FontSize',12)
set(gca().XAxis,'FontSize',12)

subplot(2,6,12)
groupSize3 = discretize([10*ones(size(min(S95.dt,[],2))); 20*ones(size(min(S95.dt_m,[],2))); 30*ones(size(min(S95.dt_mm,[],2))) ],[ 5 15 25 35],'categorical',{'Y_0','Y_{S.1}','Y_{S.2}'});
boxchart(groupSize3,[min(S95.dt,[],2); min(S95.dt_m,[],2); min(S95.dt_mm,[],2)],'GroupByColor',[ones(size(min(S95.dt,[],2))); ones(size(min(S95.dt_m,[],2))); ones(size(min(S95.dt_mm,[],2)))],'BoxFaceColor','red','MarkerColor','red')

set(gca().YAxis,'FontSize',12)
set(gca().XAxis,'FontSize',12)
yticks('')
ylim([0 1])






