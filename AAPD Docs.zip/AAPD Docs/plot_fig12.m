clear all
S = load('fig12_S.mat');
M = load('fig12_M.mat');
binEdges = [0.5 1.5 2.5 3.5 4.5 5.5 6.5 7.5 8.5 9.5 10.5];
bins = {'1', '2', '3', '4', '5', '6', '7', '8', '9', '10'};

figure(1)
subplot(3,1,1)
groupSize3 = discretize([M.t_box M.f_box],binEdges,'categorical',bins);
boxchart(groupSize3,[M.t_props M.f_props], 'GroupByColor',[M.t_type M.f_type])
xticks('')
set(gca().YAxis,'FontSize',12)
%ylim([-0.5 1.5])
ylim([-0 1])

subplot(3,1,2)
groupSize4 = discretize([M.t_box_m M.f_box_m],binEdges,'categorical',bins);
boxchart(groupSize4,[M.t_props_m M.f_props_m], 'GroupByColor',[M.t_type_m M.f_type_m])
xticks('')
set(gca().YAxis,'FontSize',12)
%ylim([-0.5 1.5])
ylim([-0 1])
ylabel('Proportion of Time Detected')


subplot(3,1,3)
groupSize5 = discretize([M.t_box_mm M.f_box_mm],binEdges,'categorical',bins);
boxchart(groupSize5,[M.t_props_mm M.f_props_mm], 'GroupByColor',[M.t_type_mm M.f_type_mm])
set(gca().YAxis,'FontSize',12)
set(gca().XAxis,'FontSize',12)
xlabel('Swarm Size')


%ylim([-0.5 1.5])
ylim([-0 1])


xlabel('No. of Degrading Robots')


figure(2)
subplot(3,1,1)
groupSize3 = discretize([S.t_box S.f_box],binEdges,'categorical',bins);
boxchart(groupSize3,[S.t_props S.f_props], 'GroupByColor',[S.t_type S.f_type])
xticks('')
set(gca().YAxis,'FontSize',12)
%ylim([-0.5 1.5])
ylim([-0 1])

subplot(3,1,2)
groupSize4 = discretize([S.t_box_m S.f_box_m],binEdges,'categorical',bins);
boxchart(groupSize4,[S.t_props_m S.f_props_m], 'GroupByColor',[S.t_type_m S.f_type_m])
xticks('')
set(gca().YAxis,'FontSize',12)
%ylim([-0.5 1.5])
ylim([-0 1])
ylabel('Proportion of Time Detected')


subplot(3,1,3)
groupSize5 = discretize([S.t_box_mm S.f_box_mm],binEdges,'categorical',bins);
boxchart(groupSize5,[S.t_props_mm S.f_props_mm], 'GroupByColor',[S.t_type_mm S.f_type_mm])
set(gca().YAxis,'FontSize',12)
set(gca().XAxis,'FontSize',12)
xlabel('Swarm Size')


%ylim([-0.5 1.5])
ylim([-0 1])


xlabel('No. of Degrading Robots')
