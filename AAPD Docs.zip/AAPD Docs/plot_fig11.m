Mc = load('fig_11_bcF.mat');
Ml = load('fig_11_lcF.mat');
S = load('fig_11_sc.mat');

binEdges = [1.5 2.5 3.5 4.5 5.5 6.5 7.5 8.5 9.5 10.5];
bins = {'2', '3', '4', '5', '6', '7', '8', '9', '10'};



figure(1)
subplot(2,1,1)
groupSize3 = discretize([Mc.t_box Mc.f_box],binEdges,'categorical',bins);
boxchart(groupSize3,[Mc.t_props Mc.f_props], 'GroupByColor',[Mc.t_type Mc.f_type])
xticks('')
ylabel('\Psi')
set(gca().YAxis,'FontSize',12)
ylim([0 1])

subplot(2,1,2)
groupSize4 = discretize([Mc.t_box_m Mc.f_box_m],binEdges,'categorical',bins);
boxchart(groupSize4,[Mc.t_props_m Mc.f_props_m], 'GroupByColor',[Mc.t_type_m Mc.f_type_m])
xticks('')
set(gca().YAxis,'FontSize',12)
ylim([0 1])
ylabel('\Psi')
xlabel('Swarm Size')

figure(2)
subplot(2,1,1)
groupSize3 = discretize([Ml.t_box Ml.f_box],binEdges,'categorical',bins);
boxchart(groupSize3,[Ml.t_props Ml.f_props], 'GroupByColor',[Ml.t_type Ml.f_type])
xticks('')
ylabel('\Psi')
set(gca().YAxis,'FontSize',12)
ylim([0 1])

subplot(2,1,2)
groupSize4 = discretize([Ml.t_box_m Ml.f_box_m],binEdges,'categorical',bins);
boxchart(groupSize4,[Ml.t_props_m Ml.f_props_m], 'GroupByColor',[Ml.t_type_m Ml.f_type_m])
xticks('')
set(gca().YAxis,'FontSize',12)
ylim([0 1])
ylabel('\Psi')
xlabel('Swarm Size')


figure(3)
subplot(2,1,1)
groupSize3 = discretize([S.t_box S.f_box],binEdges,'categorical',bins);
boxchart(groupSize3,[S.t_props S.f_props], 'GroupByColor',[S.t_type S.f_type])
xticks('')
ylabel('\Psi')
set(gca().YAxis,'FontSize',12)
ylim([0 1])

subplot(2,1,2)
groupSize4 = discretize([S.t_box_m S.f_box_m],binEdges,'categorical',bins);
boxchart(groupSize4,[S.t_props_m S.f_props_m], 'GroupByColor',[S.t_type_m S.f_type_m])
xticks('')
set(gca().YAxis,'FontSize',12)
ylim([0 1])
ylabel('\Psi')
xlabel('Swarm Size')
