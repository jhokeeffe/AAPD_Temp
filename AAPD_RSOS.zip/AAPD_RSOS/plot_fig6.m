clear all
close all
M75 = load('fig6_data_75M.mat');
M85 = load('fig6_data_85M.mat');
M95 = load('fig6_data_95M.mat');
S75 = load('fig6_data_75S.mat');
S85 = load('fig6_data_85S.mat');
S95 = load('fig6_data_95S.mat');


binEdges = [25 35 45 55 65 75 85 95];
bins = {'0.3', '0.4', '0.5', '0.6', '0.7', '0.8', '0.9'};







figure(6)
T = tiledlayout(1,2,'TileIndexing','rowmajor');
t = tiledlayout(T,2,3,'Padding','compact','TileSpacing','compact');
title(t,'A: \it{X_M}')
nexttile(t,1)
groupSize3 = discretize([10*ones(size(M75.tp_props)); 10*ones(size(M75.fp_props_single)); 20*ones(size(M75.tp_props_m)); 20*ones(size(M75.fp_props_m_single));30*ones(size(M75.tp_props_mm)); 30*ones(size(M75.fp_props_mm_single))],[ 5 15 25 35],'categorical',{'Y_0','Y_{M.1}','Y_{M.2}'});
boxchart(groupSize3,[M75.tp_props; M75.fp_props_single; M75.tp_props_m; M75.fp_props_m_single;M75.tp_props_mm; M75.fp_props_mm_single], 'GroupByColor',[ones(size(M75.tp_props)); zeros(size(M75.fp_props_single)); ones(size(M75.tp_props_m)); zeros(size(M75.fp_props_m_single));ones(size(M75.tp_props_mm)); zeros(size(M75.fp_props_mm_single))])
ylim([0 1])
xticks('')
ylabel('i: \Psi')
set(gca().YAxis,'FontSize',16)
set(gca().XAxis,'FontSize',12)
title('\rm \it{a}: 0.75 \leq \it{d_{l,r}} \leq 1','FontSize',12)

nexttile(t,2)
groupSize3 = discretize([10*ones(size(M85.tp_props)); 10*ones(size(M85.fp_props_single)); 20*ones(size(M85.tp_props_m)); 20*ones(size(M85.fp_props_m_single));30*ones(size(M85.tp_props_mm)); 30*ones(size(M85.fp_props_mm_single))],[ 5 15 25 35],'categorical',{'Y_0','Y_{M.1}','Y_{M.2}'});
boxchart(groupSize3,[M85.tp_props; M85.fp_props_single; M85.tp_props_m; M85.fp_props_m_single;M85.tp_props_mm; M85.fp_props_mm_single], 'GroupByColor',[ones(size(M85.tp_props)); zeros(size(M85.fp_props_single)); ones(size(M85.tp_props_m)); zeros(size(M85.fp_props_m_single));ones(size(M85.tp_props_mm)); zeros(size(M85.fp_props_mm_single))])
xticks('')
yticks('')
ylim([0 1])
set(gca().YAxis,'FontSize',12)
set(gca().XAxis,'FontSize',12)
title('\rm \it{b}: 0.85 \leq \it{d_{l,r}} \leq 1','FontSize',12)
nexttile(t,3)
groupSize3 = discretize([10*ones(size(M95.tp_props)); 10*ones(size(M95.fp_props_single)); 20*ones(size(M95.tp_props_m)); 20*ones(size(M95.fp_props_m_single));30*ones(size(M95.tp_props_mm)); 30*ones(size(M95.fp_props_mm_single))],[ 5 15 25 35],'categorical',{'Y_0','Y_{M.1}','Y_{M.2}'});
boxchart(groupSize3,[M95.tp_props; M95.fp_props_single; M95.tp_props_m; M95.fp_props_m_single;M95.tp_props_mm; M95.fp_props_mm_single], 'GroupByColor',[ones(size(M95.tp_props)); zeros(size(M95.fp_props_single)); ones(size(M95.tp_props_m)); zeros(size(M95.fp_props_m_single));ones(size(M95.tp_props_mm)); zeros(size(M95.fp_props_mm_single))])
xticks('')
yticks('')
ylim([0 1])
set(gca().YAxis,'FontSize',12)
set(gca().XAxis,'FontSize',12)
title('\rm \it{c}: 0.95 \leq \it{d_{l,r}} \leq 1','FontSize',12)
nexttile(t,4)
groupSize3 = discretize([10*ones(size(min(M75.dt,[],2))); 20*ones(size(min(M75.dt_m,[],2))); 30*ones(size(min(M75.dt_mm,[],2))) ],[ 5 15 25 35],'categorical',{'{\it {\bf Y}_0}','{\it {\bf Y}_{M.1}}','{\it {\bf Y}_{M.2}}'});
boxchart(groupSize3,[min(M75.dt,[],2); min(M75.dt_m,[],2); min(M75.dt_mm,[],2)],'GroupByColor',[ones(size(min(M75.dt,[],2))); ones(size(min(M75.dt_m,[],2))); ones(size(min(M75.dt_mm,[],2)))],'BoxFaceColor','green','MarkerColor','green')
set(gca().YAxis,'FontSize',16)
set(gca().XAxis,'FontSize',10)
ylabel('ii: \delta')
ylim([0 1])

nexttile(t,5)
groupSize3 = discretize([10*ones(size(min(M85.dt,[],2))); 20*ones(size(min(M85.dt_m,[],2))); 30*ones(size(min(M85.dt_mm,[],2))) ],[ 5 15 25 35],'categorical',{'{\it {\bf Y}_0}','{\it {\bf Y}_{M.1}}','{\it {\bf Y}_{M.2}}'});
boxchart(groupSize3,[min(M85.dt,[],2); min(M85.dt_m,[],2); min(M85.dt_mm,[],2)],'GroupByColor',[ones(size(min(M85.dt,[],2))); ones(size(min(M85.dt_m,[],2))); ones(size(min(M85.dt_mm,[],2)))],'BoxFaceColor','green','MarkerColor','green')
yticks('')
ylim([0 1])
set(gca().YAxis,'FontSize',12)
set(gca().XAxis,'FontSize',10)

nexttile(t,6)
groupSize3 = discretize([10*ones(size(min(M95.dt,[],2))); 20*ones(size(min(M95.dt_m,[],2))); 30*ones(size(min(M95.dt_mm,[],2))) ],[ 5 15 25 35],'categorical',{'{\it {\bf Y}_0}','{\it {\bf Y}_{M.1}}','{\it {\bf Y}_{M.2}}'});
boxchart(groupSize3,[min(M95.dt,[],2); min(M95.dt_m,[],2); min(M95.dt_mm,[],2)],'GroupByColor',[ones(size(min(M95.dt,[],2))); ones(size(min(M95.dt_m,[],2))); ones(size(min(M95.dt_mm,[],2)))],'BoxFaceColor','green','MarkerColor','green')
yticks('')
ylim([0 1])
set(gca().YAxis,'FontSize',12)
set(gca().XAxis,'FontSize',10)






tt = tiledlayout(T,2,3,'Padding','compact','TileSpacing','compact');
tt.Layout.Tile = 2;
title(tt,'B: \it{X_S}')
nexttile(tt,1)
groupSize3 = discretize([10*ones(size(S75.tp_props)); 10*ones(size(S75.fp_props_single)); 20*ones(size(S75.tp_props_m)); 20*ones(size(S75.fp_props_m_single));30*ones(size(S75.tp_props_mm)); 30*ones(size(S75.fp_props_mm_single))],[ 5 15 25 35],'categorical',{'Y_0','Y_{S.1}','Y_{S.2}'});
boxchart(groupSize3,[S75.tp_props; S75.fp_props_single; S75.tp_props_m; S75.fp_props_m_single;S75.tp_props_mm; S75.fp_props_mm_single], 'GroupByColor',[ones(size(S75.tp_props)); zeros(size(S75.fp_props_single)); ones(size(S75.tp_props_m)); zeros(size(S75.fp_props_m_single));ones(size(S75.tp_props_mm)); zeros(size(S75.fp_props_mm_single))])
xticks('')
yticks('')
ylim([0 1])
set(gca().YAxis,'FontSize',12)
set(gca().XAxis,'FontSize',12)
title('\rm \it{d}: 0.75 \leq \it{d_{l,r}} \leq 1','FontSize',12)
nexttile(tt,2)
groupSize3 = discretize([10*ones(size(S85.tp_props)); 10*ones(size(S85.fp_props_single)); 20*ones(size(S85.tp_props_m)); 20*ones(size(S85.fp_props_m_single));30*ones(size(S85.tp_props_mm)); 30*ones(size(S85.fp_props_mm_single))],[ 5 15 25 35],'categorical',{'Y_0','Y_{M.1}','Y_{M.2}'});
boxchart(groupSize3,[S85.tp_props; S85.fp_props_single; S85.tp_props_m; S85.fp_props_m_single;S85.tp_props_mm; S85.fp_props_mm_single], 'GroupByColor',[ones(size(S85.tp_props)); zeros(size(S85.fp_props_single)); ones(size(S85.tp_props_m)); zeros(size(S85.fp_props_m_single));ones(size(S85.tp_props_mm)); zeros(size(S85.fp_props_mm_single))])
xticks('')
yticks('')
ylim([0 1])
set(gca().YAxis,'FontSize',12)
set(gca().XAxis,'FontSize',12)
title('\rm \it{e}: 0.85 \leq \it{d_{l,r}} \leq 1','FontSize',12)
nexttile(tt,3)
groupSize3 = discretize([10*ones(size(S95.tp_props)); 10*ones(size(S95.fp_props_single)); 20*ones(size(S95.tp_props_m)); 20*ones(size(S95.fp_props_m_single));30*ones(size(S95.tp_props_mm)); 30*ones(size(S95.fp_props_mm_single))],[ 5 15 25 35],'categorical',{'Y_0','Y_{M.1}','Y_{M.2}'});
boxchart(groupSize3,[S95.tp_props; S95.fp_props_single; S95.tp_props_m; S95.fp_props_m_single;S95.tp_props_mm; S95.fp_props_mm_single], 'GroupByColor',[ones(size(S95.tp_props)); zeros(size(S95.fp_props_single)); ones(size(S95.tp_props_m)); zeros(size(S95.fp_props_m_single));ones(size(S95.tp_props_mm)); zeros(size(S95.fp_props_mm_single))])
ylim([0 1])
yticks('')
xticks('')
set(gca().YAxis,'FontSize',12)
set(gca().XAxis,'FontSize',12)
title('\rm \it{f}: 0.95 \leq \it{d_{l,r}} \leq 1','FontSize',12)
lgd=legend({'\Psi_F','\Psi_T'});
fontsize(lgd,14,'points')



nexttile(tt,4)
groupSize3 = discretize([10*ones(size(min(S75.dt,[],2))); 20*ones(size(min(S75.dt_m,[],2))); 30*ones(size(min(S75.dt_mm,[],2))) ],[ 5 15 25 35],'categorical',{'{\it {\bf Y}_0}','{\it {\bf Y}_{S.1}}','{\it {\bf Y}_{S.2}}'});
boxchart(groupSize3,[min(S75.dt,[],2); min(S75.dt_m,[],2); min(S75.dt_mm,[],2)],'GroupByColor',[ones(size(min(S75.dt,[],2))); ones(size(min(S75.dt_m,[],2))); ones(size(min(S75.dt_mm,[],2)))],'BoxFaceColor','green','MarkerColor','green')
yticks('')
ylim([0 1])
set(gca().YAxis,'FontSize',12)
set(gca().XAxis,'FontSize',10)
nexttile(tt,5)
groupSize3 = discretize([10*ones(size(min(S85.dt,[],2))); 20*ones(size(min(S85.dt_m,[],2))); 30*ones(size(min(S85.dt_mm,[],2))) ],[ 5 15 25 35],'categorical',{'{\it {\bf Y}_0}','{\it {\bf Y}_{S.1}}','{\it {\bf Y}_{S.2}}'});
boxchart(groupSize3,[min(S85.dt,[],2); min(S85.dt_m,[],2); min(S85.dt_mm,[],2)],'GroupByColor',[ones(size(min(S85.dt,[],2))); ones(size(min(S85.dt_m,[],2))); ones(size(min(S85.dt_mm,[],2)))],'BoxFaceColor','green','MarkerColor','green')
yticks('')
ylim([0 1])
set(gca().YAxis,'FontSize',12)
set(gca().XAxis,'FontSize',10)

nexttile(tt,6)
groupSize3 = discretize([10*ones(size(min(S95.dt,[],2))); 20*ones(size(min(S95.dt_m,[],2))); 30*ones(size(min(S95.dt_mm,[],2))) ],[ 5 15 25 35],'categorical',{'{\it {\bf Y}_0}','{\it {\bf Y}_{S.1}}','{\it {\bf Y}_{S.2}}'});
boxchart(groupSize3,[min(S95.dt,[],2); min(S95.dt_m,[],2); min(S95.dt_mm,[],2)],'GroupByColor',[ones(size(min(S95.dt,[],2))); ones(size(min(S95.dt_m,[],2))); ones(size(min(S95.dt_mm,[],2)))],'BoxFaceColor','green','MarkerColor','green')

set(gca().YAxis,'FontSize',12)
set(gca().XAxis,'FontSize',10)
yticks('')
ylim([0 1])
