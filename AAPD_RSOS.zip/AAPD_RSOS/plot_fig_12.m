load("fig_12_dat.mat")

x_lines = [30 40 50 60 70 80 90]./100;

x_axis_array = ones(1,10);
binEdges = [25 35 45 55 65 75 85 95];
bins = {'0.3', '0.4', '0.5', '0.6', '0.7', '0.8', '0.9'};
x = [30.*x_axis_array 40.*x_axis_array 50.*x_axis_array 60.*x_axis_array 70.*x_axis_array 80.*x_axis_array 90.*x_axis_array];

c = [ones(1,70) 2*ones(1,70) 3*ones(1,70)];

figure(12)
c = [ones(1,70) 2*ones(1,70)];
t = tiledlayout('flow');
nexttile;
groupSize1 = discretize([ x x],binEdges,'categorical',bins);
boxchart(groupSize1,[FE_p(2,:) FE_p(3,:)],'GroupByColor',[c])
%ylim([0 10])
xticks('')
set(gca().XAxis,'FontSize',12)
set(gca().YAxis,'FontSize',12)
title('\rm GPF Algorithm')
ylabel('Empty Environment')
nexttile;
boxchart(groupSize1,[ CE_p(2,:) CE_p(3,:)],'GroupByColor',[c])
ylim([0 8.1])
xticks('')
set(gca().XAxis,'FontSize',12)
set(gca().YAxis,'FontSize',12)
title('\rm LPF Algorithm')
%ylim([0 8])
nexttile;
boxchart(groupSize1,[FC_p(2,:) FC_p(3,:)],'GroupByColor',[c])
%ylim([0 5.1])
%xticks('')
set(gca().XAxis,'FontSize',12)
set(gca().YAxis,'FontSize',12)
ylabel('Constrained Environment')

nexttile;
boxchart(groupSize1,[CC_p(2,:) CC_p(3,:)],'GroupByColor',[c])
set(gca().XAxis,'FontSize',12)
set(gca().YAxis,'FontSize',12)
%ylim([0 3])
% hold on
% plot(median([d_5./5 d_10./10 d_20./20],2))
legend('N = 10', 'N=20')
ylabel(t, 'Resources Collected by Swarm','FontSize',15)
xlabel(t, '\it d_0','FontSize',15)
%ylim([0 10])

