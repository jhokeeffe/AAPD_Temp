clear all
load('fig_14_dat.mat');
figure(1)
subplot(1,2,1)
binEdges = [0.5 1.5 2.5 3.5 4.5];
bins = {'GPF-Open', 'GPF-Cons.', 'LPF-Open', 'LPF-Cons.'};
groupSize5 = discretize([ones(1, 10)*1 ones(1, 10)*2 ones(1, 10)*3 ones(1, 10)*4 ones(1, 20)*1 ones(1, 20)*2 ones(1, 20)*3 ones(1, 20)*4],binEdges,'categorical',bins);
boxchart(groupSize5,[GPF_O_d_10 GPF_C_d_10 LPF_O_d_10 LPF_C_d_10 GPF_O_d_20 GPF_C_d_20 LPF_O_d_20 LPF_C_d_20],'GroupByColor',[ones(1,40) ones(1,80)*2])
legend({'N = 10', 'N = 20'})
title('A','FontSize',14)
ylabel('No. of Robots w/ Power Depleted')
set(gca().XAxis,'FontSize',14)
set(gca().YAxis,'FontSize',14)
GPF_O_d_10_dS = [98 72 44 54 60 38 83 88 49 77]./100;
GPF_O_d_10_dl = [62 95 78 57 81 36 73 71 93 65]./100;
GPF_O_d_10_dr = [82 91 63 55 89 61 79 58 97 41]./100;

GPF_C_d_10_dS = [86 72 77 59 65 68 51 49 70 90]./100;
GPF_C_d_10_dl = [77 53 90 59 81 49 59 58 79 81]./100;
GPF_C_d_10_dr = [91 86 83 74 80 35 83 51 64 70]./100;

LPF_O_d_10_dS = [64 43 38 86 30 58 93 46 62 47]./100;
LPF_O_d_10_dl = [78 60 33 63 47 57 87 63 58 52]./100;
LPF_O_d_10_dr = [73 56 29 85 57 43 79 57 49 36]./100;

LPF_C_d_10_dS = [25 41 25 55 75 63 42 11 61 41]./100;
LPF_C_d_10_dl = [37 23 28 32 55 34 28 15 29 39]./100;
LPF_C_d_10_dr = [17 34 18 66 33 25 39 32 41 56]./100;

% binEdges = [0.5 1.5 2.5 3.5 4.5];
% bins = {'GPF - Open', 'GPF - Cons.', 'LPF - Open', 'LPF - Cons.'};
% x1 = ones(1, 30)*1;
% x2 = ones(1, 30)*2;
% x3 = ones(1, 30)*3;
% x4 = ones(1, 30)*4;
% c1 = [ones(1, 10)*1 ones(1, 10)*2 ones(1, 10)*3];
% GPF_O = [GPF_O_d_10_dS GPF_O_d_10_dl GPF_O_d_10_dr];
% GPF_C = [GPF_C_d_10_dS GPF_C_d_10_dl GPF_C_d_10_dr];
% LPF_O = [LPF_O_d_10_dS LPF_O_d_10_dl LPF_O_d_10_dr];
% LPF_C = [LPF_C_d_10_dS LPF_C_d_10_dl LPF_C_d_10_dr];
% groupSize5 = discretize([x1 x2 x3 x4],binEdges,'categorical',bins);
% boxchart(groupSize5,[GPF_O GPF_C LPF_O LPF_C],'GroupByColor',[c1 c1 c1 c1])
% legend({'\it{d_S}','\it{d_l}','\it{d_r}'})


subplot(1,2,2)
title('B','FontSize',14)
hold on
scatter(GPF_O_d_10_dl,GPF_O_d_10_dr,60,'filled')
scatter(GPF_C_d_10_dl,GPF_C_d_10_dr,60,'filled')
scatter(LPF_O_d_10_dl,LPF_O_d_10_dr,60,'filled')
scatter(LPF_C_d_10_dl,LPF_C_d_10_dr,60,'filled')
legend({'GPF - Open','GPF - Cons.','LPF - Open','LPF - Cons.'})
xlabel('\it{d_r}')
ylabel('\it{d_l}')
set(gca().XAxis,'FontSize',14)
set(gca().YAxis,'FontSize',14)
xlim([0 1])
ylim([0 1])