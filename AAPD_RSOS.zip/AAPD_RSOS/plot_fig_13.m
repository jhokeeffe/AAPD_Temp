%clearvars -except FE_p FE_r FC_p FC_r CE_p CE_r CC_p CC_r;
clear all;
close all;
load("fig_13_dat.mat")



x_axis_array = ones(1,20);
binEdges = [25 35 45];
bins = {'AAPD', '{\it d_0}^*'};
x = [30.*x_axis_array 40.*x_axis_array];

c = [ones(1,10) 2*ones(1,10)];
t = tiledlayout('flow');
nexttile;
groupSize1 = discretize([x],binEdges,'categorical',bins);
boxchart(groupSize1,[dt10_PFE dt20_PFE FE_R10 FE_R20],'GroupByColor',[c c])
set(gca,'linewidth',1)
set(gca,'FontSize',12)
title('\rm GPF Algorithm')
ylabel('Empty Environment')
ylim([0 10])
%xticks('')
nexttile;
groupSize1 = discretize([x],binEdges,'categorical',bins);
boxchart(groupSize1,[dt10_PCE dt20_PCE CE_R10 CE_R20],'GroupByColor',[c c])
set(gca,'linewidth',1)
set(gca,'FontSize',12)
title('\rm LPF Algorithm')
ylim([0 8])
nexttile;
groupSize1 = discretize([x],binEdges,'categorical',bins);
boxchart(groupSize1,[dt10_PFC dt20_PFC FC_R10 FC_R20],'GroupByColor',[c c])
set(gca,'linewidth',1)
set(gca,'FontSize',12)
%xticks('')
ylim([0 5])
ylabel('Constrained Environment')

nexttile;
groupSize1 = discretize([x],binEdges,'categorical',bins);
boxchart(groupSize1,[dt10_PCC dt20_PCC CC_R10 CC_R20],'GroupByColor',[c c])
set(gca,'linewidth',1)
set(gca,'FontSize',12)
ylim([0 3])
% hold on
% plot(median([d_5./5 d_10./10 d_20./20],2))
legend('N = 10', 'N=20')
ylabel(t, 'Resources Collected by Swarm','FontSize',15)
%ylim([0 10])



% figure(2)
% groupSize1 = discretize([30.*x_axis_array 40.*x_axis_array 50.*x_axis_array 60.*x_axis_array 70.*x_axis_array 80.*x_axis_array 90.*x_axis_array],binEdges,'categorical',bins);
% boxchart(groupSize1,[d_10(1,:) d_10(2,:) d_10(3,:) d_10(4,:) d_10(5,:) d_10(6,:) d_10(7,:)])
% 
% %x_axis_array = ones(1,3);
% figure(3)
% groupSize1 = discretize([30.*x_axis_array 40.*x_axis_array 50.*x_axis_array 60.*x_axis_array 70.*x_axis_array 80.*x_axis_array 90.*x_axis_array],binEdges,'categorical',bins);
% boxchart(groupSize1,[d_20(1,:) d_20(2,:) d_20(3,:) d_20(4,:) d_20(5,:) d_20(6,:) d_20(7,:)])
