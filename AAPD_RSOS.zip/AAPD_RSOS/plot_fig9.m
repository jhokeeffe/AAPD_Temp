D = load('diag_data.mat')
GT = load('diag_data_gt.mat')


cat_1 = GT.r_s_c(GT.r_s_c == 1);
cat_2 = GT.r_s_c(GT.r_s_c == 2);
cat_3 = GT.r_s_c(GT.r_s_c == 3);
cat_0 = GT.r_s_c(GT.r_s_c == 0);

d_fp = D.diag_tot(D.diag_tot == 0);
d_tp = D.diag_tot(D.diag_tot == 1);
d_mc = D.diag_tot(D.diag_tot == -1);


figure(9)
subplot(1,2,1)
pie([size(cat_0,2) size(cat_1,2) size(cat_2,2) size(cat_3,2)])
legend({'False Positive', 'Right Motor', 'Left Motor', 'Both Motors'})
subplot(1,2,2)
pie([size(d_mc,2) size(d_fp,2) size(d_tp,2)])
legend({'False Positive', 'Incorrect Diagnosis', 'Correct Diagnosis'})