clear all;
load('fig_5_data_cor.mat')

%load('fig3_14_data_v2.mat')


norm_p = max(max([p30_p.totals p40_p.totals p50_p.totals p60_p.totals p70_p.totals p80_p.totals p90_p.totals]));
norm_d = max(max([p30_d.totals p40_d.totals p50_d.totals p60_d.totals p70_d.totals p80_d.totals p90_d.totals]));



binEdges = [25 35 45 55 65 75 85 95];
bins = {'0.3', '0.4', '0.5', '0.6', '0.7', '0.8', '0.9'};

figure(5)
groupSize3 = discretize([p30_d.d; p40_d.d; p50_d.d; p60_d.d; p70_d.d; p80_d.d; p90_d.d; p30_p.d; p40_p.d; p50_p.d; p60_p.d; p70_p.d; p80_p.d; p90_p.d],binEdges,'categorical',bins);
boxchart(groupSize3,[p30_d.totals./norm_d; p40_d.totals./norm_d; p50_d.totals./norm_d; p60_d.totals./norm_d; p70_d.totals./norm_d; p80_d.totals./norm_d; p90_d.totals./norm_d; p30_p.totals./norm_p; p40_p.totals./norm_p; p50_p.totals./norm_p; p60_p.totals./norm_p; p70_p.totals./norm_p; p80_p.totals./norm_p; p90_p.totals./norm_p], 'GroupByColor',[p30_d.type; p40_d.type; p50_d.type; p60_d.type; p70_d.type; p80_d.type; p90_d.type; p30_p.type; p40_p.type; p50_p.type; p60_p.type; p70_p.type; p80_p.type; p90_p.type])
xlabel("\it d_0")
ylabel("Swarm Performance (Normalised)")
legend({'Resources Gathered', 'Power Consumed'})
set(gca,'linewidth',1)
set(gca().YAxis,'FontSize',14)
set(gca().XAxis,'FontSize',14)



