clear all
close all
S = load('fig11_S.mat');
M = load('fig11_M.mat');
binEdges = [0.5 1.5 2.5 3.5 4.5 5.5 6.5 7.5 8.5 9.5 10.5];
bins = {'1', '2', '3', '4', '5', '6', '7', '8', '9', '10'};




figure(11)
subplot(3,2,1)
groupSize3 = discretize([M.t_box M.f_box],binEdges,'categorical',bins);
boxchart(groupSize3,[M.t_props M.f_props], 'GroupByColor',[M.t_type M.f_type])
xticks('')
set(gca().YAxis,'FontSize',16)
%ylim([-0.5 1.5])
ylim([-0 1])
ylabel('i: \it{Y_0}')
title('\rm A: \it{X_M}','FontSize',14)

subplot(3,2,3)
groupSize4 = discretize([M.t_box_m M.f_box_m],binEdges,'categorical',bins);
boxchart(groupSize4,[M.t_props_m M.f_props_m], 'GroupByColor',[M.t_type_m M.f_type_m])
xticks('')
set(gca().YAxis,'FontSize',16)
%ylim([-0.5 1.5])
ylim([-0 1])
ylabel('ii: \it{Y_{M.1}}')


subplot(3,2,5)
groupSize5 = discretize([M.t_box_mm M.f_box_mm],binEdges,'categorical',bins);
boxchart(groupSize5,[M.t_props_mm M.f_props_mm], 'GroupByColor',[M.t_type_mm M.f_type_mm])
set(gca().YAxis,'FontSize',16)
set(gca().XAxis,'FontSize',12)
xlabel('Swarm Size')
ylabel('iii: \it{Y_{M.2}}')

%ylim([-0.5 1.5])
ylim([-0 1])


xlabel('No. of Degrading Robots')

subplot(3,2,2)
groupSize3 = discretize([S.t_box S.f_box],binEdges,'categorical',bins);
boxchart(groupSize3,[S.t_props S.f_props], 'GroupByColor',[S.t_type S.f_type])
xticks('')
%yticks('')
set(gca().YAxis,'FontSize',16)
%ylim([-0.5 1.5])
ylim([-0 1])
ylabel('i: \it{Y_0}')
title('\rm B: \it{X_S}','FontSize',14)
subplot(3,2,4)
groupSize4 = discretize([S.t_box_m S.f_box_m],binEdges,'categorical',bins);
boxchart(groupSize4,[S.t_props_m S.f_props_m], 'GroupByColor',[S.t_type_m S.f_type_m])
xticks('')
%yticks('')
set(gca().YAxis,'FontSize',16)
%ylim([-0.5 1.5])
ylim([-0 1])
%ylabel('Proportion of Time Detected')
ylabel('ii: \it{Y_{S.1}}')

subplot(3,2,6)
groupSize5 = discretize([S.t_box_mm S.f_box_mm],binEdges,'categorical',bins);
boxchart(groupSize5,[S.t_props_mm S.f_props_mm], 'GroupByColor',[S.t_type_mm S.f_type_mm])
set(gca().YAxis,'FontSize',16)
set(gca().XAxis,'FontSize',12)
%yticks('')
xlabel('Swarm Size')
ylabel('iii: \it{Y_{S.2}}')

%ylim([-0.5 1.5])
ylim([-0 1])
lgd=legend({'\Psi_F','\Psi_T'})
fontsize(lgd,14,'points')

xlabel('No. of Degrading Robots')